import { createFileRoute } from '@tanstack/react-router'
import { createServerFn } from '@tanstack/react-start'
import { allAbouts, allSiteSettings } from 'content-collections'
import { useEffect, useRef } from 'react'

const getAboutData = createServerFn({ method: 'GET' }).handler(async () => {
  const about = allAbouts[0] ?? null
  const settings = allSiteSettings[0] ?? null
  return { about, settings }
})

export const Route = createFileRoute('/about')({
  loader: () => getAboutData(),
  component: AboutPage,
})

function AboutPage() {
  const { about, settings } = Route.useLoaderData()
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!ref.current) return
    const els = ref.current.querySelectorAll<HTMLElement>('.fade-in')
    const io = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && e.target.classList.add('visible')),
      { threshold: 0.1 }
    )
    els.forEach((el) => io.observe(el))
    return () => io.disconnect()
  }, [])

  const info = [
    { label: 'Name', value: about?.name },
    { label: 'Email', value: about?.email },
    { label: 'Location', value: about?.location },
    { label: 'Languages', value: about?.languages },
  ]

  const socials = [
    { label: 'GitHub', url: settings?.github, icon: '⌨️' },
    { label: 'YouTube', url: settings?.youtube, icon: '▶️' },
    { label: 'Instagram', url: settings?.instagram, icon: '📷' },
    { label: 'LinkedIn', url: settings?.linkedin, icon: '💼' },
  ]

  return (
    <div ref={ref} style={{ minHeight: '100vh', padding: '5rem 1.5rem' }}>
      <div style={{ maxWidth: '1100px', margin: '0 auto' }}>
        {/* Header */}
        <div className="fade-in" style={{ marginBottom: '4rem', textAlign: 'center' }}>
          <p style={{ color: 'var(--accent-cyan)', fontSize: '0.85rem', fontWeight: 600, letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: '0.5rem' }}>
            Get to know me
          </p>
          <h1 className="section-title">About Me</h1>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '3rem', alignItems: 'start' }}>
          {/* Left — photo + info */}
          <div>
            <div className="fade-in glass-card" style={{ overflow: 'hidden', marginBottom: '1.5rem' }}>
              <div className="img-placeholder" style={{ height: '360px' }}>
                {about?.profileImage
                  ? <img src={about.profileImage} alt={about.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                  : <span style={{ fontSize: '4rem' }}>👤</span>
                }
              </div>
            </div>

            {/* Personal info */}
            <div className="glass-card fade-in fade-in-delay-1" style={{ padding: '1.5rem' }}>
              <h3 style={{ fontSize: '1rem', fontWeight: 600, marginBottom: '1rem', color: 'var(--accent-cyan)' }}>Personal Info</h3>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                {info.map(({ label, value }) => value ? (
                  <div key={label} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid var(--border-color)', paddingBottom: '0.5rem' }}>
                    <span style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>{label}</span>
                    <span style={{ color: 'var(--text-primary)', fontSize: '0.9rem', fontWeight: 500 }}>{value}</span>
                  </div>
                ) : null)}
              </div>

              {about?.cvFile && (
                <a
                  href={about.cvFile}
                  download
                  className="btn-primary"
                  style={{ display: 'flex', justifyContent: 'center', marginTop: '1.5rem', textAlign: 'center' }}
                >
                  ⬇ Download CV
                </a>
              )}
            </div>

            {/* Social links */}
            <div className="glass-card fade-in fade-in-delay-2" style={{ padding: '1.5rem', marginTop: '1.5rem' }}>
              <h3 style={{ fontSize: '1rem', fontWeight: 600, marginBottom: '1rem', color: 'var(--accent-cyan)' }}>Find me on</h3>
              <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap' }}>
                {socials.filter((s) => s.url).map(({ label, url, icon }) => (
                  <a key={label} href={url!} target="_blank" rel="noopener noreferrer" className="social-btn" title={label}>
                    <span style={{ fontSize: '1.1rem' }}>{icon}</span>
                  </a>
                ))}
              </div>
            </div>
          </div>

          {/* Right — bio */}
          <div>
            <div className="glass-card fade-in fade-in-delay-1" style={{ padding: '2.5rem' }}>
              <h2 style={{ fontSize: '1.8rem', fontWeight: 700, marginBottom: '1.5rem' }}>
                Hi, I'm <span className="gradient-text">{about?.name ?? 'Alex'}</span>
              </h2>
              {about?.title && (
                <p style={{ color: 'var(--accent-purple)', fontWeight: 600, marginBottom: '1.5rem', fontSize: '1rem' }}>
                  {about.title}
                </p>
              )}
              <p style={{ fontSize: '1.05rem', lineHeight: 1.8, color: 'var(--text-secondary)' }}>
                {about?.bio ?? 'Passionate 3D artist and game developer with years of experience crafting immersive digital worlds.'}
              </p>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', marginTop: '2.5rem' }}>
                {[
                  { value: '6+', label: 'Years Experience' },
                  { value: '40+', label: 'Projects Completed' },
                  { value: '3', label: 'Games Shipped' },
                  { value: '100%', label: 'Passion' },
                ].map(({ value, label }) => (
                  <div key={label} style={{ textAlign: 'center', padding: '1.25rem', background: 'rgba(0,212,255,0.04)', borderRadius: 'var(--radius)', border: '1px solid rgba(0,212,255,0.1)' }}>
                    <div className="gradient-text" style={{ fontSize: '1.8rem', fontWeight: 700, fontFamily: "'Space Grotesk', sans-serif" }}>{value}</div>
                    <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginTop: '0.25rem' }}>{label}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
