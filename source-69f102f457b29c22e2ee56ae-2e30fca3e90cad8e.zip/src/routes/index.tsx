import { createFileRoute, Link } from '@tanstack/react-router'
import { createServerFn } from '@tanstack/react-start'
import { allProjects, allSiteSettings } from 'content-collections'
import { useEffect, useRef } from 'react'

const getHomeData = createServerFn({ method: 'GET' }).handler(async () => {
  const featured = allProjects
    .filter((p) => p.featured)
    .sort((a, b) => a.order - b.order)
    .slice(0, 6)
  const settings = allSiteSettings[0] ?? null
  return { featured, settings }
})

export const Route = createFileRoute('/')({
  loader: () => getHomeData(),
  component: HomePage,
})

function useFadeIn(dep?: unknown) {
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    if (!ref.current) return
    const els = ref.current.querySelectorAll<HTMLElement>('.fade-in')
    const io = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && e.target.classList.add('visible')),
      { threshold: 0.1 }
    )
    els.forEach((el) => io.observe(el))
    return () => io.disconnect()
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dep])
  return ref
}

const quickSkills = [
  { name: 'Blender', icon: '🎨' },
  { name: 'Unity', icon: '🎮' },
  { name: '3D Modeling', icon: '🗿' },
  { name: 'C#', icon: '💻' },
  { name: 'Texturing', icon: '🖌️' },
  { name: 'Game Design', icon: '🕹️' },
  { name: 'VR/AR', icon: '🥽' },
  { name: 'Lighting', icon: '💡' },
]

function HomePage() {
  const { featured, settings } = Route.useLoaderData()
  const pageRef = useFadeIn()

  return (
    <div ref={pageRef} style={{ minHeight: '100vh' }}>
      {/* ── Hero ── */}
      <section
        style={{
          position: 'relative',
          minHeight: 'calc(100vh - 64px)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          textAlign: 'center',
          overflow: 'hidden',
          padding: '4rem 1.5rem',
        }}
      >
        <div className="ambient-glow ambient-glow-cyan" style={{ top: '-100px', left: '20%', position: 'absolute' }} />
        <div className="ambient-glow ambient-glow-purple" style={{ bottom: '0', right: '10%', position: 'absolute' }} />
        <div style={{ position: 'relative', zIndex: 1, maxWidth: '820px' }}>
          <p className="hero-title" style={{ color: 'var(--accent-cyan)', fontSize: '0.85rem', fontWeight: 600, letterSpacing: '0.15em', textTransform: 'uppercase', marginBottom: '1rem' }}>
            Welcome to my portfolio
          </p>
          <h1 className="hero-title" style={{ fontSize: 'clamp(2.5rem, 7vw, 5rem)', fontWeight: 700, lineHeight: 1.08, marginBottom: '1.5rem' }}>
            {settings?.siteName ?? 'Alex Renderer'}
            <br />
            <span className="gradient-text">{settings?.siteTitle ?? '3D Artist & Game Developer'}</span>
          </h1>
          <p className="hero-subtitle" style={{ fontSize: '1.1rem', color: 'var(--text-secondary)', maxWidth: '560px', margin: '0 auto 2.5rem', lineHeight: 1.7 }}>
            Crafting immersive digital worlds through art, code, and imagination.
            From photorealistic renders to real-time game environments.
          </p>
          <div className="hero-cta" style={{ display: 'flex', gap: '1rem', justifyContent: 'center', flexWrap: 'wrap' }}>
            <Link to="/projects" className="btn-primary">View Projects</Link>
            <Link to="/contact" className="btn-outline">Get in Touch</Link>
          </div>
          <div style={{ marginTop: '4rem', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '0.5rem', color: 'var(--text-muted)', fontSize: '0.75rem', letterSpacing: '0.1em', textTransform: 'uppercase' }}>
            <span>Scroll</span>
            <div style={{ width: '1px', height: '40px', background: 'linear-gradient(to bottom, var(--accent-cyan), transparent)' }} />
          </div>
        </div>
      </section>

      <hr className="glow-line" />

      {/* ── Featured Projects ── */}
      <section style={{ maxWidth: '1200px', margin: '0 auto', padding: '6rem 1.5rem' }}>
        <div style={{ textAlign: 'center', marginBottom: '3rem' }}>
          <p className="fade-in" style={{ color: 'var(--accent-cyan)', fontSize: '0.8rem', fontWeight: 600, letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: '0.5rem' }}>
            Selected Work
          </p>
          <h2 className="section-title fade-in fade-in-delay-1">Featured Projects</h2>
          <p className="section-subtitle fade-in fade-in-delay-2">A curated selection of my best work</p>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: '1.5rem' }}>
          {featured.map((project, i) => (
            <div key={project._meta.path} className={`glass-card fade-in fade-in-delay-${Math.min(i + 1, 5)}`} style={{ overflow: 'hidden' }}>
              <div className="img-placeholder" style={{ height: '200px', borderRadius: 'var(--radius) var(--radius) 0 0' }}>
                {project.coverImage || project.image
                  ? <img src={project.coverImage ?? project.image} alt={project.title} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                  : <span style={{ fontSize: '0.85rem' }}>📸 {project.title}</span>
                }
              </div>
              <div style={{ padding: '1.5rem' }}>
                {project.category && (
                  <span className="tag tag-purple" style={{ marginBottom: '0.6rem', display: 'inline-block' }}>{project.category}</span>
                )}
                <h3 style={{ fontSize: '1.1rem', fontWeight: 600, marginBottom: '0.5rem', color: 'var(--text-primary)' }}>{project.title}</h3>
                <p style={{ fontSize: '0.875rem', color: 'var(--text-secondary)', marginBottom: '1rem', lineHeight: 1.6 }}>
                  {project.description?.slice(0, 110)}…
                </p>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.4rem' }}>
                  {project.tags.slice(0, 3).map((tag) => (
                    <span key={tag} className="tag">{tag}</span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>

        <div style={{ textAlign: 'center', marginTop: '3rem' }}>
          <Link to="/projects" className="btn-outline">View All Projects →</Link>
        </div>
      </section>

      <hr className="glow-line" />

      {/* ── Quick Skills ── */}
      <section style={{ maxWidth: '1200px', margin: '0 auto', padding: '6rem 1.5rem' }}>
        <div style={{ textAlign: 'center', marginBottom: '3rem' }}>
          <p className="fade-in" style={{ color: 'var(--accent-cyan)', fontSize: '0.8rem', fontWeight: 600, letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: '0.5rem' }}>
            Expertise
          </p>
          <h2 className="section-title fade-in fade-in-delay-1">Skills & Tools</h2>
        </div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '1rem', justifyContent: 'center' }}>
          {quickSkills.map((s, i) => (
            <div key={s.name} className={`glass-card fade-in fade-in-delay-${Math.min(i + 1, 5)}`} style={{ padding: '0.9rem 1.4rem', display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
              <span style={{ fontSize: '1.3rem' }}>{s.icon}</span>
              <span style={{ fontWeight: 500, fontSize: '0.9rem' }}>{s.name}</span>
            </div>
          ))}
        </div>
        <div style={{ textAlign: 'center', marginTop: '2.5rem' }}>
          <Link to="/skills" className="btn-outline">See Full Skills →</Link>
        </div>
      </section>
    </div>
  )
}
