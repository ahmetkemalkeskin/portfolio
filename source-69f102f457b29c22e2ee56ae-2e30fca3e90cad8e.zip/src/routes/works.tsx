import { createFileRoute } from '@tanstack/react-router'
import { createServerFn } from '@tanstack/react-start'
import { allWorks } from 'content-collections'
import { useEffect, useRef, useState } from 'react'

const getWorksData = createServerFn({ method: 'GET' }).handler(async () => {
  const works = allWorks.sort((a, b) => a.order - b.order)
  return { works }
})

export const Route = createFileRoute('/works')({
  loader: () => getWorksData(),
  component: WorksPage,
})

type WorkItem = typeof allWorks[number]

const CATEGORIES = ['All', '3D Models', 'Game Screenshots', 'Videos']

function Lightbox({ item, onClose }: { item: WorkItem; onClose: () => void }) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose()
    window.addEventListener('keydown', onKey)
    document.body.style.overflow = 'hidden'
    return () => { window.removeEventListener('keydown', onKey); document.body.style.overflow = '' }
  }, [onClose])

  return (
    <div className="lightbox-overlay" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div style={{ maxWidth: '900px', width: '100%', position: 'relative' }}>
        <button onClick={onClose} style={{ position: 'absolute', top: '-2.5rem', right: 0, background: 'none', border: 'none', color: 'white', fontSize: '1.5rem', cursor: 'pointer' }}>✕</button>
        {item.youtubeUrl ? (
          <div style={{ borderRadius: 'var(--radius)', overflow: 'hidden' }}>
            <iframe src={item.youtubeUrl} title={item.title} style={{ width: '100%', height: '500px', border: 'none' }} allowFullScreen />
          </div>
        ) : item.image ? (
          <img src={item.image} alt={item.title} style={{ width: '100%', maxHeight: '80vh', objectFit: 'contain', borderRadius: 'var(--radius)' }} />
        ) : (
          <div className="img-placeholder" style={{ height: '400px', borderRadius: 'var(--radius)' }}>
            <span>📸 {item.title}</span>
          </div>
        )}
        <div style={{ marginTop: '1rem', textAlign: 'center' }}>
          <h3 style={{ fontWeight: 600, marginBottom: '0.25rem' }}>{item.title}</h3>
          {item.description && <p style={{ color: 'var(--text-secondary)', fontSize: '0.9rem' }}>{item.description}</p>}
        </div>
      </div>
    </div>
  )
}

function WorksPage() {
  const { works } = Route.useLoaderData()
  const [filter, setFilter] = useState('All')
  const [lightbox, setLightbox] = useState<WorkItem | null>(null)
  const ref = useRef<HTMLDivElement>(null)

  const filtered = filter === 'All' ? works : works.filter((w) => w.category === filter)

  useEffect(() => {
    if (!ref.current) return
    const els = ref.current.querySelectorAll<HTMLElement>('.fade-in:not(.visible)')
    const io = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && e.target.classList.add('visible')),
      { threshold: 0.1 }
    )
    els.forEach((el) => io.observe(el))
    return () => io.disconnect()
  }, [filtered])

  return (
    <div ref={ref} style={{ minHeight: '100vh', padding: '5rem 1.5rem' }}>
      <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
        <div className="fade-in" style={{ textAlign: 'center', marginBottom: '3rem' }}>
          <p style={{ color: 'var(--accent-cyan)', fontSize: '0.8rem', fontWeight: 600, letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: '0.5rem' }}>Gallery</p>
          <h1 className="section-title">Works & Gallery</h1>
          <p className="section-subtitle">3D models, game screenshots, and video showcases</p>
        </div>

        {/* Filter tabs */}
        <div className="fade-in fade-in-delay-1" style={{ display: 'flex', gap: '0.75rem', justifyContent: 'center', flexWrap: 'wrap', marginBottom: '3rem' }}>
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setFilter(cat)}
              style={{
                padding: '0.45rem 1.2rem', borderRadius: '999px', border: '1px solid',
                borderColor: filter === cat ? 'var(--accent-cyan)' : 'var(--border-color)',
                background: filter === cat ? 'rgba(0,212,255,0.1)' : 'transparent',
                color: filter === cat ? 'var(--accent-cyan)' : 'var(--text-secondary)',
                cursor: 'pointer', fontSize: '0.875rem', fontWeight: 500, transition: 'all 0.2s ease',
              }}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Masonry-style grid */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: '1.25rem' }}>
          {filtered.map((item, i) => (
            <div
              key={item._meta.path}
              className={`glass-card fade-in fade-in-delay-${Math.min(i + 1, 5)}`}
              style={{ overflow: 'hidden', cursor: 'pointer' }}
              onClick={() => setLightbox(item)}
            >
              <div className="img-placeholder" style={{ height: '220px', position: 'relative', overflow: 'hidden' }}>
                {item.image
                  ? <img src={item.image} alt={item.title} style={{ width: '100%', height: '100%', objectFit: 'cover', transition: 'transform 0.4s ease' }} onMouseOver={(e) => { (e.currentTarget as HTMLImageElement).style.transform = 'scale(1.08)' }} onMouseOut={(e) => { (e.currentTarget as HTMLImageElement).style.transform = 'scale(1)' }} />
                  : item.youtubeUrl
                  ? (
                    <div style={{ width: '100%', height: '100%', background: 'rgba(168,85,247,0.08)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '0.5rem' }}>
                      <span style={{ fontSize: '2.5rem' }}>▶</span>
                      <span style={{ color: 'var(--text-muted)', fontSize: '0.8rem' }}>Video</span>
                    </div>
                  )
                  : <span>📸 {item.title}</span>
                }
                {/* Category badge */}
                <span className="tag" style={{ position: 'absolute', top: '0.75rem', left: '0.75rem', background: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(8px)' }}>
                  {item.category}
                </span>
                {/* Hover overlay */}
                <div style={{
                  position: 'absolute', inset: 0,
                  background: 'linear-gradient(to top, rgba(0,0,0,0.7), transparent)',
                  opacity: 0, transition: 'opacity 0.3s ease',
                  display: 'flex', alignItems: 'flex-end', padding: '1rem',
                }}
                  onMouseOver={(e) => { (e.currentTarget as HTMLDivElement).style.opacity = '1' }}
                  onMouseOut={(e) => { (e.currentTarget as HTMLDivElement).style.opacity = '0' }}
                >
                  <span style={{ color: 'white', fontSize: '0.85rem', fontWeight: 500 }}>🔍 View</span>
                </div>
              </div>
              <div style={{ padding: '1rem' }}>
                <h3 style={{ fontSize: '0.95rem', fontWeight: 600, marginBottom: '0.25rem' }}>{item.title}</h3>
                {item.description && (
                  <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)', lineHeight: 1.5 }}>{item.description.slice(0, 80)}…</p>
                )}
              </div>
            </div>
          ))}
        </div>

        {filtered.length === 0 && (
          <div style={{ textAlign: 'center', padding: '4rem', color: 'var(--text-muted)' }}>
            No items in this category yet.
          </div>
        )}
      </div>

      {lightbox && <Lightbox item={lightbox} onClose={() => setLightbox(null)} />}
    </div>
  )
}
