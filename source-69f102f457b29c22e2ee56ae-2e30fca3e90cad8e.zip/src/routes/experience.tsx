import { createFileRoute } from '@tanstack/react-router'
import { createServerFn } from '@tanstack/react-start'
import { allExperiences } from 'content-collections'
import { useEffect, useRef } from 'react'

const getExperienceData = createServerFn({ method: 'GET' }).handler(async () => {
  const entries = allExperiences.sort((a, b) => a.order - b.order)
  return { entries }
})

export const Route = createFileRoute('/experience')({
  loader: () => getExperienceData(),
  component: ExperiencePage,
})

function ExperiencePage() {
  const { entries } = Route.useLoaderData()
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!ref.current) return
    const els = ref.current.querySelectorAll<HTMLElement>('.fade-in')
    const io = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && e.target.classList.add('visible')),
      { threshold: 0.15 }
    )
    els.forEach((el) => io.observe(el))
    return () => io.disconnect()
  }, [])

  return (
    <div ref={ref} style={{ minHeight: '100vh', padding: '5rem 1.5rem' }}>
      <div style={{ maxWidth: '800px', margin: '0 auto' }}>
        <div className="fade-in" style={{ textAlign: 'center', marginBottom: '4rem' }}>
          <p style={{ color: 'var(--accent-cyan)', fontSize: '0.8rem', fontWeight: 600, letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: '0.5rem' }}>Career</p>
          <h1 className="section-title">Experience</h1>
          <p className="section-subtitle">My professional journey in art and development</p>
        </div>

        {/* Timeline */}
        <div style={{ position: 'relative' }}>
          {/* Vertical line */}
          <div style={{
            position: 'absolute',
            left: '28px',
            top: '8px',
            bottom: '8px',
            width: '1px',
            background: 'linear-gradient(to bottom, var(--accent-cyan), var(--accent-purple), transparent)',
            opacity: 0.25,
          }} />

          <div style={{ display: 'flex', flexDirection: 'column', gap: '2.5rem' }}>
            {entries.map((entry, i) => (
              <div key={entry._meta.path} className={`fade-in fade-in-delay-${Math.min(i + 1, 5)}`} style={{ display: 'flex', gap: '1.5rem', alignItems: 'flex-start' }}>
                {/* Dot */}
                <div style={{ flexShrink: 0, paddingTop: '0.3rem' }}>
                  <div className="timeline-dot" style={{ width: '14px', height: '14px', borderRadius: '50%', background: 'linear-gradient(135deg, #00d4ff, #a855f7)', boxShadow: '0 0 16px rgba(0,212,255,0.5)' }} />
                </div>

                {/* Card */}
                <div className="glass-card" style={{ padding: '1.5rem 2rem', flex: 1 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '0.5rem', marginBottom: '0.5rem' }}>
                    <h3 style={{ fontSize: '1.1rem', fontWeight: 700, color: 'var(--text-primary)' }}>{entry.title}</h3>
                    <span className="tag" style={{ whiteSpace: 'nowrap' }}>{entry.date}</span>
                  </div>
                  {entry.company && (
                    <p style={{ color: 'var(--accent-cyan)', fontSize: '0.9rem', fontWeight: 500, marginBottom: '0.75rem' }}>{entry.company}</p>
                  )}
                  {entry.description && (
                    <p style={{ color: 'var(--text-secondary)', fontSize: '0.9rem', lineHeight: 1.7 }}>{entry.description}</p>
                  )}
                  {entry.image && (
                    <img src={entry.image} alt={entry.title} style={{ marginTop: '1rem', width: '100%', borderRadius: 'var(--radius)', maxHeight: '200px', objectFit: 'cover' }} />
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {entries.length === 0 && (
          <div style={{ textAlign: 'center', color: 'var(--text-muted)', padding: '4rem' }}>
            Experience coming soon.
          </div>
        )}
      </div>
    </div>
  )
}
