import { createFileRoute } from '@tanstack/react-router'
import { createServerFn } from '@tanstack/react-start'
import { allSkillCategories } from 'content-collections'
import { useEffect, useRef, useState } from 'react'

const getSkillsData = createServerFn({ method: 'GET' }).handler(async () => {
  const categories = allSkillCategories.sort((a, b) => a.order - b.order)
  return { categories }
})

export const Route = createFileRoute('/skills')({
  loader: () => getSkillsData(),
  component: SkillsPage,
})

function AnimatedBar({ percentage, visible }: { percentage: number; visible: boolean }) {
  return (
    <div className="skill-bar-track">
      <div
        className="skill-bar-fill"
        style={{ transform: visible ? `scaleX(${percentage / 100})` : 'scaleX(0)' }}
      />
    </div>
  )
}

function SkillsPage() {
  const { categories } = Route.useLoaderData()
  const ref = useRef<HTMLDivElement>(null)
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    if (!ref.current) return
    const els = ref.current.querySelectorAll<HTMLElement>('.fade-in')
    const io = new IntersectionObserver(
      (entries) => entries.forEach((e) => {
        if (e.isIntersecting) {
          e.target.classList.add('visible')
          setVisible(true)
        }
      }),
      { threshold: 0.1 }
    )
    els.forEach((el) => io.observe(el))
    return () => io.disconnect()
  }, [])

  return (
    <div ref={ref} style={{ minHeight: '100vh', padding: '5rem 1.5rem' }}>
      <div style={{ maxWidth: '1000px', margin: '0 auto' }}>
        <div className="fade-in" style={{ textAlign: 'center', marginBottom: '4rem' }}>
          <p style={{ color: 'var(--accent-cyan)', fontSize: '0.8rem', fontWeight: 600, letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: '0.5rem' }}>Capabilities</p>
          <h1 className="section-title">Skills & Expertise</h1>
          <p className="section-subtitle">My technical toolkit, refined through years of practice</p>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(420px, 1fr))', gap: '2rem' }}>
          {categories.map((cat, ci) => (
            <div key={cat._meta.path} className={`glass-card fade-in fade-in-delay-${Math.min(ci + 1, 4)}`} style={{ padding: '2rem' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '1.75rem' }}>
                <div style={{ width: '3px', height: '1.5rem', background: 'var(--accent-gradient)', borderRadius: '2px' }} />
                <h2 style={{ fontSize: '1.1rem', fontWeight: 700, color: 'var(--text-primary)' }}>{cat.category}</h2>
              </div>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
                {cat.items.map((skill) => (
                  <div key={skill.name}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.4rem' }}>
                      <span style={{ fontSize: '0.9rem', fontWeight: 500, color: 'var(--text-primary)' }}>{skill.name}</span>
                      <span style={{ fontSize: '0.85rem', color: 'var(--accent-cyan)', fontWeight: 600 }}>{skill.percentage}%</span>
                    </div>
                    <AnimatedBar percentage={skill.percentage} visible={visible} />
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {categories.length === 0 && (
          <div style={{ textAlign: 'center', color: 'var(--text-muted)', padding: '4rem' }}>
            Skills coming soon.
          </div>
        )}
      </div>
    </div>
  )
}
