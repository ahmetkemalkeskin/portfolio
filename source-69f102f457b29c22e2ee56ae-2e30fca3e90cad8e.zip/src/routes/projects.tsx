import { createFileRoute } from '@tanstack/react-router'
import { createServerFn } from '@tanstack/react-start'
import { allProjects } from 'content-collections'
import { useEffect, useRef, useState } from 'react'

const getProjectsData = createServerFn({ method: 'GET' }).handler(async () => {
  const projects = allProjects.sort((a, b) => a.order - b.order)
  return { projects }
})

export const Route = createFileRoute('/projects')({
  loader: () => getProjectsData(),
  component: ProjectsPage,
})

type ProjectItem = typeof allProjects[number]

function ProjectModal({ project, onClose }: { project: ProjectItem; onClose: () => void }) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose()
    window.addEventListener('keydown', onKey)
    document.body.style.overflow = 'hidden'
    return () => {
      window.removeEventListener('keydown', onKey)
      document.body.style.overflow = ''
    }
  }, [onClose])

  return (
    <div className="lightbox-overlay" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="glass-card" style={{ maxWidth: '820px', width: '100%', maxHeight: '90vh', overflow: 'auto', padding: '2rem' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '1.5rem' }}>
          <div>
            {project.category && <span className="tag tag-purple" style={{ marginBottom: '0.5rem', display: 'inline-block' }}>{project.category}</span>}
            <h2 style={{ fontSize: '1.5rem', fontWeight: 700 }}>{project.title}</h2>
          </div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', fontSize: '1.5rem', cursor: 'pointer', lineHeight: 1, padding: '0 0 0 1rem' }}>✕</button>
        </div>

        {project.coverImage || project.image ? (
          <img src={project.coverImage ?? project.image} alt={project.title} style={{ width: '100%', height: '300px', objectFit: 'cover', borderRadius: 'var(--radius)', marginBottom: '1.5rem' }} />
        ) : (
          <div className="img-placeholder" style={{ height: '280px', borderRadius: 'var(--radius)', marginBottom: '1.5rem' }}>
            <span>📸 {project.title}</span>
          </div>
        )}

        {project.youtubeUrl && (
          <div style={{ marginBottom: '1.5rem', borderRadius: 'var(--radius)', overflow: 'hidden' }}>
            <iframe src={project.youtubeUrl} title={project.title} style={{ width: '100%', height: '320px', border: 'none' }} allowFullScreen />
          </div>
        )}

        <p style={{ lineHeight: 1.8, marginBottom: '1.5rem', color: 'var(--text-secondary)' }}>{project.description}</p>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.4rem' }}>
          {project.tags.map((tag) => <span key={tag} className="tag">{tag}</span>)}
        </div>
      </div>
    </div>
  )
}

function ProjectsPage() {
  const { projects } = Route.useLoaderData()
  const [selected, setSelected] = useState<ProjectItem | null>(null)
  const ref = useRef<HTMLDivElement>(null)
  const allCategories = ['All', ...Array.from(new Set(projects.map((p) => p.category).filter(Boolean) as string[]))]
  const [filter, setFilter] = useState('All')
  const filtered = filter === 'All' ? projects : projects.filter((p) => p.category === filter)

  useEffect(() => {
    if (!ref.current) return
    const els = ref.current.querySelectorAll<HTMLElement>('.fade-in:not(.visible)')
    const io = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && e.target.classList.add('visible')),
      { threshold: 0.1 }
    )
    els.forEach((el) => io.observe(el))
    return () => io.disconnect()
  }, [filtered])

  return (
    <div ref={ref} style={{ minHeight: '100vh', padding: '5rem 1.5rem' }}>
      <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
        <div className="fade-in" style={{ textAlign: 'center', marginBottom: '3rem' }}>
          <p style={{ color: 'var(--accent-cyan)', fontSize: '0.8rem', fontWeight: 600, letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: '0.5rem' }}>Portfolio</p>
          <h1 className="section-title">My Projects</h1>
          <p className="section-subtitle">Games, 3D art, and interactive experiences</p>
        </div>

        {/* Filter */}
        <div className="fade-in fade-in-delay-1" style={{ display: 'flex', gap: '0.75rem', justifyContent: 'center', flexWrap: 'wrap', marginBottom: '3rem' }}>
          {allCategories.map((cat) => (
            <button
              key={cat}
              onClick={() => setFilter(cat)}
              style={{
                padding: '0.45rem 1.2rem', borderRadius: '999px', border: '1px solid',
                borderColor: filter === cat ? 'var(--accent-cyan)' : 'var(--border-color)',
                background: filter === cat ? 'rgba(0,212,255,0.1)' : 'transparent',
                color: filter === cat ? 'var(--accent-cyan)' : 'var(--text-secondary)',
                cursor: 'pointer', fontSize: '0.875rem', fontWeight: 500, transition: 'all 0.2s ease',
              }}
            >
              {cat}
            </button>
          ))}
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: '1.5rem' }}>
          {filtered.map((project, i) => (
            <div
              key={project._meta.path}
              className={`glass-card fade-in fade-in-delay-${Math.min(i + 1, 5)}`}
              style={{ overflow: 'hidden', cursor: 'pointer' }}
              onClick={() => setSelected(project)}
            >
              <div className="img-placeholder" style={{ height: '200px', borderRadius: 'var(--radius) var(--radius) 0 0', overflow: 'hidden', position: 'relative' }}>
                {project.coverImage || project.image
                  ? <img src={project.coverImage ?? project.image} alt={project.title} style={{ width: '100%', height: '100%', objectFit: 'cover', transition: 'transform 0.4s ease' }} onMouseOver={(e) => { (e.currentTarget as HTMLImageElement).style.transform = 'scale(1.06)' }} onMouseOut={(e) => { (e.currentTarget as HTMLImageElement).style.transform = 'scale(1)' }} />
                  : <span style={{ fontSize: '0.85rem' }}>📸 No image</span>
                }
                {project.featured && (
                  <span className="tag" style={{ position: 'absolute', top: '0.75rem', right: '0.75rem', background: 'rgba(0,212,255,0.9)', color: '#000' }}>Featured</span>
                )}
              </div>
              <div style={{ padding: '1.5rem' }}>
                {project.category && <span className="tag tag-purple" style={{ marginBottom: '0.5rem', display: 'inline-block' }}>{project.category}</span>}
                <h3 style={{ fontSize: '1.05rem', fontWeight: 600, marginBottom: '0.5rem' }}>{project.title}</h3>
                <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', lineHeight: 1.6, marginBottom: '1rem' }}>
                  {project.description?.slice(0, 110)}…
                </p>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.35rem' }}>
                  {project.tags.slice(0, 3).map((tag) => <span key={tag} className="tag">{tag}</span>)}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {selected && <ProjectModal project={selected} onClose={() => setSelected(null)} />}
    </div>
  )
}
