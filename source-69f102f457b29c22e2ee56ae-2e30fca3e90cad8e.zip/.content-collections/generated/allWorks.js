
export default [
  {
    "title": "Dungeon Crawler Prototype",
    "category": "Game Screenshots",
    "image": "/images/uploads/work-dungeon.jpg",
    "description": "Screenshot from dungeon crawler prototype. Procedural level generation with dynamic lighting.",
    "order": 4,
    "content": "",
    "_meta": {
      "filePath": "dungeon.md",
      "fileName": "dungeon.md",
      "directory": ".",
      "extension": "md",
      "path": "dungeon"
    }
  },
  {
    "title": "Fantasy Environment Scene",
    "category": "3D Models",
    "image": "/images/uploads/work-environment.jpg",
    "description": "Detailed fantasy forest environment with custom shaders and volumetric lighting.",
    "order": 2,
    "content": "",
    "_meta": {
      "filePath": "environment.md",
      "fileName": "environment.md",
      "directory": ".",
      "extension": "md",
      "path": "environment"
    }
  },
  {
    "title": "Neon City — Game Level",
    "category": "Game Screenshots",
    "image": "/images/uploads/work-neon-city.jpg",
    "description": "In-game screenshot from Neon City Runner. Cyberpunk aesthetic with real-time global illumination.",
    "order": 3,
    "content": "",
    "_meta": {
      "filePath": "neon-city.md",
      "fileName": "neon-city.md",
      "directory": ".",
      "extension": "md",
      "path": "neon-city"
    }
  },
  {
    "title": "Blender Timelapse — Character Sculpt",
    "category": "Videos",
    "youtubeUrl": "https://www.youtube.com/embed/dQw4w9WgXcQ",
    "description": "Full timelapse of a character sculpt from base mesh to final render. Made in Blender 4.x.",
    "order": 5,
    "content": "",
    "_meta": {
      "filePath": "sculpt-timelapse.md",
      "fileName": "sculpt-timelapse.md",
      "directory": ".",
      "extension": "md",
      "path": "sculpt-timelapse"
    }
  },
  {
    "title": "Sci-Fi Spaceship Model",
    "category": "3D Models",
    "image": "/images/uploads/work-spaceship.jpg",
    "description": "High-poly spaceship model with PBR textures. Rendered in Cycles with full lighting setup.",
    "order": 1,
    "content": "",
    "_meta": {
      "filePath": "spaceship.md",
      "fileName": "spaceship.md",
      "directory": ".",
      "extension": "md",
      "path": "spaceship"
    }
  }
]