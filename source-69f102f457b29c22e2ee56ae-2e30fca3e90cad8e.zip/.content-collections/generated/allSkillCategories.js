
export default [
  {
    "category": "3D Art",
    "order": 1,
    "items": [
      {
        "name": "Blender",
        "percentage": 92
      },
      {
        "name": "3D Modeling",
        "percentage": 90
      },
      {
        "name": "Texturing & Materials",
        "percentage": 85
      },
      {
        "name": "Lighting & Rendering",
        "percentage": 88
      },
      {
        "name": "Character Animation",
        "percentage": 75
      },
      {
        "name": "ZBrush Sculpting",
        "percentage": 80
      }
    ],
    "content": "",
    "_meta": {
      "filePath": "3d-art.md",
      "fileName": "3d-art.md",
      "directory": ".",
      "extension": "md",
      "path": "3d-art"
    }
  },
  {
    "category": "Game Development",
    "order": 2,
    "items": [
      {
        "name": "Unity",
        "percentage": 88
      },
      {
        "name": "C# Programming",
        "percentage": 82
      },
      {
        "name": "Game Design",
        "percentage": 85
      },
      {
        "name": "Unreal Engine",
        "percentage": 70
      },
      {
        "name": "Shader Development",
        "percentage": 72
      },
      {
        "name": "VR/AR Development",
        "percentage": 65
      }
    ],
    "content": "",
    "_meta": {
      "filePath": "game-dev.md",
      "fileName": "game-dev.md",
      "directory": ".",
      "extension": "md",
      "path": "game-dev"
    }
  }
]