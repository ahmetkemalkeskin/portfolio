
export default [
  {
    "title": "Orbital Defense",
    "description": "A top-down space strategy game with real-time physics simulation, procedurally generated galaxies, and an adaptive AI system. Built with Unity and C#.",
    "tags": [
      "Unity",
      "C#",
      "AI",
      "Physics",
      "Strategy"
    ],
    "image": "/images/uploads/project-orbital.jpg",
    "coverImage": "/images/uploads/project-orbital.jpg",
    "gallery": [],
    "youtubeUrl": "",
    "category": "Game Development",
    "featured": true,
    "order": 3,
    "content": "Orbital Defense is a real-time strategy game set in procedurally generated galaxy systems. Players manage fleets, build orbital stations, and repel waves of increasingly intelligent AI enemies.",
    "_meta": {
      "filePath": "orbital-defense.md",
      "fileName": "orbital-defense.md",
      "directory": ".",
      "extension": "md",
      "path": "orbital-defense"
    }
  },
  {
    "title": "Neon City Runner",
    "description": "A cyberpunk endless runner built in Unity with procedurally generated levels, neon-lit cityscapes, and custom shader effects. Features dynamic music sync and global leaderboards.",
    "tags": [
      "Unity",
      "C#",
      "Game Design",
      "Procedural Generation"
    ],
    "image": "/images/uploads/project-neon-city.jpg",
    "coverImage": "/images/uploads/project-neon-city.jpg",
    "gallery": [],
    "youtubeUrl": "",
    "category": "Game Development",
    "featured": true,
    "order": 1,
    "content": "Neon City Runner is a fast-paced cyberpunk endless runner built entirely in Unity. The game features procedurally generated city environments, custom HLSL shaders for neon effects, and a reactive soundtrack that syncs to gameplay intensity.",
    "_meta": {
      "filePath": "portfolio-site.md",
      "fileName": "portfolio-site.md",
      "directory": ".",
      "extension": "md",
      "path": "portfolio-site"
    }
  },
  {
    "title": "Phantomscape VR",
    "description": "An immersive VR horror experience developed for Meta Quest 2. Features hand-tracked interactions, spatial audio, and over 40 unique 3D assets created entirely in Blender.",
    "tags": [
      "Blender",
      "Unity",
      "VR",
      "3D Modeling",
      "Spatial Audio"
    ],
    "image": "/images/uploads/project-phantomscape.jpg",
    "coverImage": "/images/uploads/project-phantomscape.jpg",
    "gallery": [],
    "youtubeUrl": "",
    "category": "VR / 3D Art",
    "featured": true,
    "order": 2,
    "content": "Phantomscape VR is a psychological horror experience designed for Meta Quest 2. Every prop, character, and environment was hand-crafted in Blender and brought to life in Unity with custom shaders, hand tracking, and spatial audio design.",
    "_meta": {
      "filePath": "task-manager.md",
      "fileName": "task-manager.md",
      "directory": ".",
      "extension": "md",
      "path": "task-manager"
    }
  }
]