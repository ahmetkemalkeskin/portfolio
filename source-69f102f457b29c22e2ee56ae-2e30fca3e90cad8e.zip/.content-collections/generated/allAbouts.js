
export default [
  {
    "name": "Alex Renderer",
    "title": "3D Artist & Game Developer",
    "email": "alex@example.com",
    "location": "New York, USA",
    "languages": "English, Spanish",
    "profileImage": "/images/uploads/profile.jpg",
    "cvFile": "/files/cv.pdf",
    "bio": "Passionate 3D artist and game developer with 6+ years of experience crafting immersive digital worlds. Specializing in photorealistic rendering, character modeling, and real-time game environments. I bridge the gap between artistic vision and technical execution — from concept through final render.",
    "content": "",
    "_meta": {
      "filePath": "main.md",
      "fileName": "main.md",
      "directory": ".",
      "extension": "md",
      "path": "main"
    }
  }
]