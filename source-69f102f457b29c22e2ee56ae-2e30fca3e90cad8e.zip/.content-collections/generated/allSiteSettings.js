
export default [
  {
    "siteName": "Alex Renderer",
    "siteTitle": "3D Artist & Game Developer",
    "email": "alex@example.com",
    "phone": "+1 (555) 000-0000",
    "github": "https://github.com/alexrenderer",
    "youtube": "https://youtube.com/@alexrenderer",
    "instagram": "https://instagram.com/alexrenderer",
    "linkedin": "https://linkedin.com/in/alexrenderer",
    "mapsEmbed": "",
    "content": "",
    "_meta": {
      "filePath": "site.md",
      "fileName": "site.md",
      "directory": ".",
      "extension": "md",
      "path": "site"
    }
  }
]