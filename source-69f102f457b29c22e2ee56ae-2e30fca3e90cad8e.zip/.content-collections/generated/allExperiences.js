
export default [
  {
    "date": "2022 — Present",
    "title": "Senior 3D Artist",
    "company": "Neon Pixel Studios",
    "description": "Lead 3D artist responsible for all environmental assets and character models for AAA mobile titles. Collaborated closely with the game design team to translate concepts into production-ready assets optimized for real-time rendering.",
    "order": 1,
    "content": "",
    "_meta": {
      "filePath": "exp-1.md",
      "fileName": "exp-1.md",
      "directory": ".",
      "extension": "md",
      "path": "exp-1"
    }
  },
  {
    "date": "2020 — 2022",
    "title": "3D Generalist",
    "company": "Orbital Creative Agency",
    "description": "Created high-quality 3D visualizations and animations for architectural clients and product campaigns. Delivered photorealistic renders and motion graphics for advertising and marketing materials.",
    "order": 2,
    "content": "",
    "_meta": {
      "filePath": "exp-2.md",
      "fileName": "exp-2.md",
      "directory": ".",
      "extension": "md",
      "path": "exp-2"
    }
  },
  {
    "date": "2018 — 2020",
    "title": "Junior Game Developer",
    "company": "Indie Collective",
    "description": "Developed and shipped three indie games using Unity. Handled game mechanics, UI systems, and level design. Contributed 3D assets and animations for all shipped titles.",
    "order": 3,
    "content": "",
    "_meta": {
      "filePath": "exp-3.md",
      "fileName": "exp-3.md",
      "directory": ".",
      "extension": "md",
      "path": "exp-3"
    }
  },
  {
    "date": "2016 — 2018",
    "title": "Freelance 3D Artist",
    "company": "Self-employed",
    "description": "Provided freelance 3D modeling and visualization services to clients across architecture, product design, and entertainment sectors. Built a portfolio of diverse work spanning multiple industries.",
    "order": 4,
    "content": "",
    "_meta": {
      "filePath": "exp-4.md",
      "fileName": "exp-4.md",
      "directory": ".",
      "extension": "md",
      "path": "exp-4"
    }
  }
]