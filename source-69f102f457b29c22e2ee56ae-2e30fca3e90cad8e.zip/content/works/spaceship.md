---
title: "Sci-Fi Spaceship Model"
category: "3D Models"
image: /images/uploads/work-spaceship.jpg
description: "High-poly spaceship model with PBR textures. Rendered in Cycles with full lighting setup."
order: 1
---
