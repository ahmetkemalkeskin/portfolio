---
title: "Blender Timelapse — Character Sculpt"
category: "Videos"
youtubeUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ"
description: "Full timelapse of a character sculpt from base mesh to final render. Made in Blender 4.x."
order: 5
---
