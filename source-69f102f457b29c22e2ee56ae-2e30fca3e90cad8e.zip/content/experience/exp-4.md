---
date: "2016 — 2018"
title: "Freelance 3D Artist"
company: "Self-employed"
description: "Provided freelance 3D modeling and visualization services to clients across architecture, product design, and entertainment sectors. Built a portfolio of diverse work spanning multiple industries."
order: 4
---
