---
date: "2020 — 2022"
title: "3D Generalist"
company: "Orbital Creative Agency"
description: "Created high-quality 3D visualizations and animations for architectural clients and product campaigns. Delivered photorealistic renders and motion graphics for advertising and marketing materials."
order: 2
---
