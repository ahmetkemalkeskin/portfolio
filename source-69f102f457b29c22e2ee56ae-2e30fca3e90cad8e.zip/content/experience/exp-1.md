---
date: "2022 — Present"
title: "Senior 3D Artist"
company: "Neon Pixel Studios"
description: "Lead 3D artist responsible for all environmental assets and character models for AAA mobile titles. Collaborated closely with the game design team to translate concepts into production-ready assets optimized for real-time rendering."
order: 1
---
