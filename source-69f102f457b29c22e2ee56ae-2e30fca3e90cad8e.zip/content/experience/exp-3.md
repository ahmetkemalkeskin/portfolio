---
date: "2018 — 2020"
title: "Junior Game Developer"
company: "Indie Collective"
description: "Developed and shipped three indie games using Unity. Handled game mechanics, UI systems, and level design. Contributed 3D assets and animations for all shipped titles."
order: 3
---
