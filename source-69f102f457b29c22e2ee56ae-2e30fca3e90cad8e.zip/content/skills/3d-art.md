---
category: "3D Art"
order: 1
items:
  - name: "Blender"
    percentage: 92
  - name: "3D Modeling"
    percentage: 90
  - name: "Texturing & Materials"
    percentage: 85
  - name: "Lighting & Rendering"
    percentage: 88
  - name: "Character Animation"
    percentage: 75
  - name: "ZBrush Sculpting"
    percentage: 80
---
