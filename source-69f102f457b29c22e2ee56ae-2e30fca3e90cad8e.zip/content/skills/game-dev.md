---
category: "Game Development"
order: 2
items:
  - name: "Unity"
    percentage: 88
  - name: "C# Programming"
    percentage: 82
  - name: "Game Design"
    percentage: 85
  - name: "Unreal Engine"
    percentage: 70
  - name: "Shader Development"
    percentage: 72
  - name: "VR/AR Development"
    percentage: 65
---
