---
title: "Neon City Runner"
description: "A cyberpunk endless runner built in Unity with procedurally generated levels, neon-lit cityscapes, and custom shader effects. Features dynamic music sync and global leaderboards."
tags: ["Unity", "C#", "Game Design", "Procedural Generation"]
image: /images/uploads/project-neon-city.jpg
coverImage: /images/uploads/project-neon-city.jpg
gallery: []
youtubeUrl: ""
category: "Game Development"
featured: true
order: 1
---

Neon City Runner is a fast-paced cyberpunk endless runner built entirely in Unity. The game features procedurally generated city environments, custom HLSL shaders for neon effects, and a reactive soundtrack that syncs to gameplay intensity.
