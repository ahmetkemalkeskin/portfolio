---
title: "Phantomscape VR"
description: "An immersive VR horror experience developed for Meta Quest 2. Features hand-tracked interactions, spatial audio, and over 40 unique 3D assets created entirely in Blender."
tags: ["Blender", "Unity", "VR", "3D Modeling", "Spatial Audio"]
image: /images/uploads/project-phantomscape.jpg
coverImage: /images/uploads/project-phantomscape.jpg
gallery: []
youtubeUrl: ""
category: "VR / 3D Art"
featured: true
order: 2
---

Phantomscape VR is a psychological horror experience designed for Meta Quest 2. Every prop, character, and environment was hand-crafted in Blender and brought to life in Unity with custom shaders, hand tracking, and spatial audio design.
