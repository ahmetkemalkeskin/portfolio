---
title: "Orbital Defense"
description: "A top-down space strategy game with real-time physics simulation, procedurally generated galaxies, and an adaptive AI system. Built with Unity and C#."
tags: ["Unity", "C#", "AI", "Physics", "Strategy"]
image: /images/uploads/project-orbital.jpg
coverImage: /images/uploads/project-orbital.jpg
gallery: []
youtubeUrl: ""
category: "Game Development"
featured: true
order: 3
content: ""
---

Orbital Defense is a real-time strategy game set in procedurally generated galaxy systems. Players manage fleets, build orbital stations, and repel waves of increasingly intelligent AI enemies.
